# Multi-Layer Perceptron for Diabetes Prediction: An Empirical Analysis of Architectural Depth vs Width

**Sadman Sharif**  
**Student ID: A1944825**  
**University of Adelaide**  
**sadman.sharif@student.adelaide.edu.au**

---

## 1. Introduction

Diabetes mellitus affects over 537 million adults globally, with early detection crucial for preventing severe complications. This work implements and evaluates Multi-Layer Perceptrons (MLPs) for binary diabetes classification using the Pima Indians Diabetes dataset, addressing the fundamental challenge of capturing complex physiological patterns while maintaining model generalizability.

The perceptron, foundational to deep learning, transforms inputs through weighted combinations and activation functions:

**y = f(Σ(w_i × x_i) + b)**

where x_i represents input features, w_i denotes weights, b is the bias term, and f(·) is the activation function. MLPs extend this concept through layered architectures, enabling hierarchical feature learning essential for medical diagnosis.

This study systematically investigates three architectural variations—shallow, deep, and wide networks—to determine optimal configurations for medical prediction tasks. Our methodology encompasses comprehensive data preprocessing, including biologically-informed imputation of missing values and standardized feature scaling. The experimental framework evaluates how architectural choices influence learning dynamics, with particular emphasis on the depth versus width trade-off.

**Key contributions include:**
1. Empirical demonstration that architectural depth outperforms width for medical data, achieving 77.92% accuracy with 66% fewer parameters
2. Analysis of sensitivity-specificity trade-offs critical for clinical deployment
3. Insights into efficient parameter utilization in medical MLPs

---

## 2. Method

### 2.1 Data Preprocessing

The dataset comprises 768 samples with 8 physiological features: pregnancies, glucose, blood pressure, skin thickness, insulin, BMI, diabetes pedigree function, and age. Initial analysis revealed biologically impossible zero values in glucose (5.5%), blood pressure (4.5%), skin thickness (29.6%), insulin (48.7%), and BMI (1.4%) measurements. These were treated as missing values and imputed using median statistics from the training distribution to maintain physiological validity.

Feature standardization employed z-score normalization:
**x' = (x - μ_train) / σ_train**

Data partitioning utilized stratified sampling:
- Training: 492 samples (63.5%)
- Validation: 123 samples (16%)
- Test: 155 samples (20.5%)

This preserved the 65:35 class distribution (non-diabetic:diabetic) across all splits.

### 2.2 Network Architecture

We implemented a flexible MLP framework using PyTorch, enabling systematic architectural exploration. Each configuration follows the pattern:

**Input(8) → Hidden Layers → Output(1)**

Hidden layers employ the composition:
- Linear transformation: z = Wx + b
- Activation: ReLU(z)
- Regularization: Dropout(p)

The output layer uses sigmoid activation for binary classification:
**ŷ = σ(w^T h + b) = 1 / (1 + e^(-(w^T h + b)))**

Three architectural configurations were evaluated:

| **Model** | **Architecture** | **Parameters** |
|-----------|-----------------|----------------|
| Shallow | [32] | 321 |
| Deep | [64, 32, 16] | 3,201 |
| Wide | [128, 64] | 9,473 |

### 2.3 Training Procedure

Optimization employed Binary Cross-Entropy loss:
**L = -(1/N)Σ[y_i log(ŷ_i) + (1-y_i)log(1-ŷ_i)]**

Adam optimizer with architecture-specific learning rates (0.001 for shallow/deep, 0.0005 for wide) and L2 regularization (λ=10^-4) prevented overfitting. Dropout rates were tuned per architecture (0.2-0.3). Training ran for 150 epochs with batch sizes optimized for convergence stability.

---

## 3. Experimental Analysis

### 3.1 Experimental Design

Three experiments systematically varied architectural properties while maintaining consistent training protocols. Hyperparameters were selected through preliminary validation experiments:

| **Configuration** | **Learning Rate** | **Batch Size** | **Dropout** |
|------------------|------------------|----------------|-------------|
| Shallow [32] | 0.001 | 32 | 0.20 |
| Deep [64,32,16] | 0.001 | 32 | 0.30 |
| Wide [128,64] | 0.0005 | 64 | 0.25 |

Performance evaluation employed accuracy, precision, recall, and F1-score metrics, with particular emphasis on recall given the medical context where false negatives carry severe consequences.

### 3.2 Results and Discussion

**Table 1: Test Set Performance Metrics**

| **Model** | **Accuracy** | **Precision** | **Recall** | **F1-Score** |
|-----------|-------------|---------------|------------|--------------|
| Shallow | 76.62% | 72.92% | 60.34% | 66.04% |
| **Deep** | **77.92%** | 68.75% | **75.86%** | **72.13%** |
| Wide | 72.73% | 64.29% | 62.07% | 63.16% |

The deep network achieved superior performance across key metrics. Analysis reveals three critical insights:

**1. Depth Superiority:** Despite having 66% fewer parameters than the wide network, the deep architecture achieved 5.2% higher accuracy and 9% better F1-score. This demonstrates that hierarchical feature abstraction through depth more effectively captures medical patterns than increased width. The progressive refinement across layers—from basic feature combinations (64 neurons) through intermediate patterns (32 neurons) to high-level indicators (16 neurons)—mirrors the hierarchical nature of physiological relationships.

**2. Clinical Relevance:** The deep network's 75.86% recall represents crucial clinical value, correctly identifying 44 of 58 diabetic patients versus only 35 with the shallow network. In screening applications, this 25% improvement in sensitivity significantly reduces missed diagnoses. The precision-recall trade-off (68.75% precision) indicates some false positives, acceptable in screening contexts where follow-up testing can confirm diagnoses.

**Confusion Matrix - Deep Network:**
```
                 Predicted
              No Diab  Diab
Actual No       76     20   (Specificity: 79.2%)
       Yes      14     44   (Sensitivity: 75.9%)
```

**3. Parameter Efficiency:** The wide network's underperformance despite 3× more parameters suggests inefficient capacity utilization. Training curves revealed slower convergence and higher validation-test gap (10.2%), indicating overfitting tendencies. This reinforces that architectural design matters more than raw parameter count.

**Learning Dynamics Analysis:**
- **Shallow networks:** Plateaued early (epoch 40), suggesting insufficient capacity
- **Deep networks:** Gradual improvement throughout training, indicating effective capacity utilization
- **Wide networks:** Oscillatory behavior, suggesting optimization difficulties in high-dimensional parameter spaces

The validation-test generalization gap provided additional insights:
- Shallow: 6.3% gap
- Deep: 1.8% gap (best generalization)
- Wide: 10.2% gap

---

## 4. Conclusion

This study empirically demonstrates that architectural depth provides superior performance for diabetes prediction, with the 3-layer deep network achieving 77.92% accuracy and 72.13% F1-score while maintaining parameter efficiency. The key finding—that depth enables more effective feature learning than width—has important implications for medical ML applications where interpretable hierarchical representations aid clinical understanding.

The deep network's high sensitivity (75.86%) makes it suitable for clinical screening, though the 24.14% false negative rate necessitates careful deployment with appropriate clinical oversight. Future work should address class imbalance through techniques like SMOTE or focal loss, explore attention mechanisms for feature importance visualization, and validate performance across diverse populations.

This work contributes to understanding optimal MLP design for medical applications, demonstrating that thoughtful architectural choices can achieve strong performance without excessive parameterization, crucial for deployment in resource-constrained clinical environments. The results support the broader deep learning principle that depth facilitates learning of increasingly abstract representations, essential for capturing subtle patterns distinguishing diabetic from non-diabetic patients.

---

## References

1. International Diabetes Federation. (2021). *IDF Diabetes Atlas*, 10th edition. Brussels, Belgium: International Diabetes Federation.

2. Kingma, D. P., & Ba, J. (2015). Adam: A method for stochastic optimization. In *International Conference on Learning Representations (ICLR)*.

3. Smith, J. W., Everhart, J. E., Dickson, W. C., Knowler, W. C., & Johannes, R. S. (1988). Using the ADAP learning algorithm to forecast the onset of diabetes mellitus. In *Proceedings of the Annual Symposium on Computer Application in Medical Care* (pp. 261-265).

4. Goodfellow, I., Bengio, Y., & Courville, A. (2016). *Deep Learning*. MIT Press.

5. Srivastava, N., Hinton, G., Krizhevsky, A., Sutskever, I., & Salakhutdinov, R. (2014). Dropout: A simple way to prevent neural networks from overfitting. *Journal of Machine Learning Research*, 15(56), 1929-1958.
